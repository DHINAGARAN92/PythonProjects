import { useState, useEffect } from 'react';
import { PDFUploader } from './components/PDFUploader';
import { PDFViewer } from './components/PDFViewer';
import {
  Download,
  Check,
  Type,
  Loader2,
  Layers,
  Palette,
  MousePointer2,
  RefreshCcw,
  Sparkles,
  ChevronRight,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from './utils/cn';
import type { Tag, StructureItem } from './types';

const COLORS = [
  '#6366f1', // Indigo (Primary)
  '#f43f5e', // Rose
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#3b82f6', // Blue
  '#8b5cf6', // Violet
  '#ec4899', // Pink
  '#64748b', // Slate
];

const TAG_TEXT_OPTIONS = [
  'APPROVED',
  'CONFIDENTIAL',
  'DRAFT',
  'REVIEWED',
  'SIGN HERE',
  'URGENT',
];

function App() {
  const [file, setFile] = useState<File | null>(null);
  const [tags, setTags] = useState<Tag[]>([]);
  const [structure, setStructure] = useState<StructureItem[]>([]);
  const [activeColor, setActiveColor] = useState(COLORS[0]);
  const [activeText, setActiveText] = useState(TAG_TEXT_OPTIONS[0]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processSuccess, setProcessSuccess] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  // Clear success notification after 5 seconds
  useEffect(() => {
    if (processSuccess) {
      const timer = setTimeout(() => setProcessSuccess(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [processSuccess]);

  const handleAddTag = (tagData: Omit<Tag, 'id'>) => {
    const newTag: Tag = {
      ...tagData,
      id: Math.random().toString(36).substr(2, 9),
      text: activeText,
    };
    setTags(prev => [...prev, newTag]);
  };

  const handleRemoveTag = (id: string) => {
    setTags(prev => prev.filter(t => t.id !== id));
  };

  const triggerDownload = async (urlToDownload: string) => {
    try {
      // Fetching the file as a blob ensures we bypass many browser/origin restrictions
      const response = await fetch(urlToDownload);
      if (!response.ok) throw new Error('Download failed');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `tagged-${file?.name || 'document.pdf'}`);
      document.body.appendChild(link);
      link.click();

      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Download error:', err);
      // Fallback to direct location if blob fails
      window.location.href = urlToDownload;
    }
  };

  const handleAutoTagDownload = async () => {
    if (!file) return;

    // If already processed, the UI will show the <a> tag directly. 
    // This block is a fallback for programmatic triggers.
    if (downloadUrl) {
      triggerDownload(downloadUrl);
      return;
    }

    setIsProcessing(true);
    setProcessSuccess(false);
    setDownloadUrl(null);

    const formData = new FormData();
    formData.append('pdf', file);

    try {
      const response = await fetch('/api/tag', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Tagging failed');

      const data = await response.json();

      if (data.structure) {
        setStructure(data.structure);
      }

      if (data.downloadUrl) {
        setDownloadUrl(data.downloadUrl);
        setProcessSuccess(true);
      }
    } catch (err) {
      console.error(err);
      alert('Failed to auto-tag PDF. Ensure the backend server is running.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Premium Header */}
      <header className="h-16 px-6 glass-panel z-50 sticky top-0 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center border border-primary/20 shadow-inner">
            <Sparkles className="w-6 h-6 text-primary animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-slate-800">
              PDF Tagger <span className="text-sm font-medium text-slate-400 mx-1">/</span> <span className="text-primary/80">Pro</span>
            </h1>
            <p className="text-[10px] font-bold uppercase tracking-widest text-primary/60 -mt-1">Structural Analysis Engine</p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {file && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="flex items-center gap-3"
            >
              <button
                onClick={() => {
                  setFile(null);
                  setTags([]);
                  setStructure([]);
                }}
                className="px-4 py-2 text-sm font-semibold text-slate-500 hover:text-slate-800 transition-colors flex items-center gap-2"
              >
                <RefreshCcw className="w-4 h-4 opacity-50" />
                Change Document
              </button>

              {downloadUrl ? (
                <a
                  href={downloadUrl}
                  download={`tagged-${file?.name || 'document.pdf'}`}
                  onClick={(e) => e.stopPropagation()}
                  className={cn(
                    "relative h-10 px-6 rounded-full font-bold text-sm transition-all shadow-lg flex items-center gap-2 overflow-hidden",
                    "bg-emerald-500 text-white shadow-emerald-500/30 hover:shadow-emerald-500/50 hover:-translate-y-0.5"
                  )}
                >
                  <Download className="w-4 h-4" />
                  Download Tagged PDF
                </a>
              ) : (
                <button
                  onClick={handleAutoTagDownload}
                  disabled={isProcessing}
                  className={cn(
                    "relative h-10 px-6 rounded-full font-bold text-sm transition-all shadow-lg shadow-primary/20 flex items-center gap-2 overflow-hidden",
                    "bg-primary text-white hover:shadow-primary/40 hover:-translate-y-0.5 active:translate-y-0"
                  )}
                >
                  {isProcessing ? (
                    <Loader2 className="animate-spin w-4 h-4" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  {isProcessing ? 'Analyzing...' : 'Run AI Auto-Tag'}

                  {isProcessing && (
                    <motion.div
                      initial={{ left: '-100%' }}
                      animate={{ left: '100%' }}
                      transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
                    />
                  )}
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main className="flex-1 flex overflow-hidden">
        <AnimatePresence mode="wait">
          {!file ? (
            <motion.div
              key="uploader"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex-1 flex items-center justify-center"
            >
              <PDFUploader onFileSelect={setFile} />
            </motion.div>
          ) : (
            <motion.div
              key="workspace"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex-1 flex w-full"
            >
              {/* Sidebar Controls */}
              <aside className="w-80 border-r bg-white flex flex-col shadow-[4px_0_24px_-12px_rgba(0,0,0,0.1)] z-40">
                <div className="p-6 space-y-8 overflow-y-auto">

                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-slate-400">
                      <FileText className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase tracking-wider">Active File</span>
                    </div>
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <p className="text-sm font-semibold text-slate-700 truncate">{file.name}</p>
                      <p className="text-[10px] text-slate-400 font-medium">{(file.size / 1024 / 1024).toFixed(2)} MB • Ready</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Layers className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase tracking-wider">Tag Presets</span>
                    </div>
                    <div className="grid grid-cols-1 gap-2">
                      {TAG_TEXT_OPTIONS.map(text => (
                        <button
                          key={text}
                          onClick={() => setActiveText(text)}
                          className={cn(
                            "group px-4 py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-between border",
                            activeText === text
                              ? "bg-primary text-white border-primary shadow-lg shadow-primary/20 -translate-x-1"
                              : "bg-white text-slate-600 border-slate-100 hover:border-slate-200 hover:bg-slate-50"
                          )}
                        >
                          {text}
                          <ChevronRight className={cn(
                            "w-4 h-4 transition-transform",
                            activeText === text ? "translate-x-0 opacity-100" : "-translate-x-2 opacity-0 group-hover:translate-x-0 group-hover:opacity-100"
                          )} />
                        </button>
                      ))}
                      <div className="mt-2 relative group">
                        <input
                          type="text"
                          placeholder="Create custom tag..."
                          className="w-full h-11 px-4 rounded-xl border border-slate-100 bg-slate-50 text-sm focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all pr-10"
                          value={TAG_TEXT_OPTIONS.includes(activeText) ? '' : activeText}
                          onChange={(e) => setActiveText(e.target.value)}
                        />
                        <Type className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 pointer-events-none" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Palette className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase tracking-wider">Palette</span>
                    </div>
                    <div className="grid grid-cols-4 gap-4 px-2">
                      {COLORS.map(color => (
                        <button
                          key={color}
                          onClick={() => setActiveColor(color)}
                          className={cn(
                            "w-10 h-10 rounded-2xl transition-all relative group flex items-center justify-center",
                            activeColor === color
                              ? "ring-4 ring-primary/10 scale-110 shadow-lg shadow-black/10"
                              : "hover:scale-105"
                          )}
                          style={{ backgroundColor: color }}
                        >
                          {activeColor === color && (
                            <motion.div layoutId="color-check">
                              <Check className="w-5 h-5 text-white drop-shadow-sm" />
                            </motion.div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-auto p-4 m-4 bg-primary/5 rounded-2xl border border-primary/10">
                  <div className="flex gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <MousePointer2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-primary uppercase tracking-wide">Interaction</p>
                      <p className="text-xs text-slate-500 font-medium leading-relaxed mt-1">
                        Click on the PDF to place <span className="text-slate-800 font-bold">"{activeText}"</span> at your cursor position.
                      </p>
                    </div>
                  </div>
                </div>
              </aside>

              {/* Main Viewer with Focus Effect */}
              <div className="flex-1 bg-slate-200/50 relative overflow-hidden flex flex-col">
                {isProcessing && (
                  <div className="absolute inset-0 z-50 pointer-events-none">
                    <div className="absolute top-0 left-0 w-full h-1 scanning-beam opacity-50" />
                    <div className="absolute inset-0 bg-primary/5 backdrop-blur-[2px] animate-pulse" />
                  </div>
                )}

                <div className="flex-1 overflow-auto scroll-smooth">
                  <PDFViewer
                    file={file}
                    tags={tags}
                    structure={structure}
                    onAddTag={handleAddTag}
                    onRemoveTag={handleRemoveTag}
                    activeColor={activeColor}
                  />
                </div>

                {/* Status Overlay */}
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-50">
                  <AnimatePresence>
                    {(isProcessing || processSuccess) && (
                      <motion.div
                        initial={{ opacity: 0, y: 20, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 20, scale: 0.9 }}
                        className={cn(
                          "glass-panel px-6 py-3 rounded-full flex items-center gap-3 font-semibold text-sm shadow-2xl border-white/50",
                          processSuccess ? "text-emerald-600" : "text-primary"
                        )}
                      >
                        {isProcessing ? (
                          <Loader2 className="animate-spin w-4 h-4" />
                        ) : (
                          <Check className="w-4 h-4" />
                        )}
                        {isProcessing ? "AI Model Running: Analyzing Document Structure..." : "Tagging Complete: Metadata Linkage Successful"}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

export default App;
