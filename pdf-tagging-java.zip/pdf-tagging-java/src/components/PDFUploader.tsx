import React, { useCallback, useState } from 'react';
import { Upload, FileUp, Sparkles, FileText, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../utils/cn';

interface PDFUploaderProps {
    onFileSelect: (file: File) => void;
}

export const PDFUploader: React.FC<PDFUploaderProps> = ({ onFileSelect }) => {
    const [isDragging, setIsDragging] = useState(false);
    const [isHovered, setIsHovered] = useState(false);

    const handleDragOver = useCallback((e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    }, []);

    const handleDragLeave = useCallback((e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
    }, []);

    const handleDrop = useCallback((e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);

        const files = Array.from(e.dataTransfer.files);
        const pdfFile = files.find(f => f.type === 'application/pdf');

        if (pdfFile) {
            onFileSelect(pdfFile);
        } else {
            // Could add a nice toast notification here
            alert('Please drop a PDF file');
        }
    }, [onFileSelect]);

    const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files[0] && files[0].type === 'application/pdf') {
            onFileSelect(files[0]);
        }
    }, [onFileSelect]);

    return (
        <div className="w-full max-w-2xl mx-auto px-6">
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center mb-10"
            >
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 rounded-full text-primary text-xs font-bold uppercase tracking-wider mb-4 border border-primary/20">
                    <Sparkles className="w-3 h-3" />
                    Next-Gen Accessibility Engine
                </div>
                <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight mb-3">
                    Transform your PDFs
                </h2>
                <p className="text-slate-500 max-w-md mx-auto leading-relaxed">
                    Upload your document to generate structural tags, satisfy compliance, and enable perfect assistive compatibility.
                </p>
            </motion.div>

            <motion.div
                onHoverStart={() => setIsHovered(true)}
                onHoverEnd={() => setIsHovered(false)}
                className={cn(
                    "relative group cursor-pointer transition-all duration-500",
                    isDragging ? "scale-105" : "hover:scale-[1.02]"
                )}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById('file-input')?.click()}
            >
                {/* Decorative Background Elements */}
                <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 to-violet-500/20 rounded-[2rem] blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className={cn(
                    "relative bg-white rounded-[1.75rem] border-2 border-dashed p-16 transition-all duration-500 flex flex-col items-center",
                    isDragging
                        ? "border-primary bg-primary/[0.02] shadow-2xl shadow-primary/10"
                        : "border-slate-200 hover:border-primary/40 shadow-sm"
                )}>
                    <input
                        id="file-input"
                        type="file"
                        accept=".pdf"
                        className="hidden"
                        onChange={handleFileInput}
                    />

                    <div className="relative mb-8">
                        <AnimatePresence mode="wait">
                            <motion.div
                                key={isDragging ? 'dragging' : 'normal'}
                                initial={{ scale: 0.8, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                exit={{ scale: 0.8, opacity: 0 }}
                                className={cn(
                                    "w-24 h-24 rounded-3xl flex items-center justify-center transition-all duration-500 shadow-inner",
                                    isDragging ? "bg-primary text-white" : "bg-slate-50 text-slate-400 group-hover:bg-primary/10 group-hover:text-primary"
                                )}
                            >
                                {isDragging ? (
                                    <FileUp className="w-10 h-10" />
                                ) : (
                                    <Upload className="w-10 h-10 group-hover:animate-bounce" />
                                )}
                            </motion.div>
                        </AnimatePresence>

                        {/* Floating Status Badges */}
                        <motion.div
                            animate={{ y: isHovered ? -5 : 0 }}
                            className="absolute -top-3 -right-3 w-10 h-10 bg-white rounded-2xl shadow-lg border border-slate-100 flex items-center justify-center text-emerald-500"
                        >
                            <CheckCircle2 className="w-6 h-6" />
                        </motion.div>
                        <motion.div
                            animate={{ y: isHovered ? 5 : 0 }}
                            className="absolute -bottom-3 -left-3 w-10 h-10 bg-white rounded-2xl shadow-lg border border-slate-100 flex items-center justify-center text-primary"
                        >
                            <FileText className="w-6 h-6" />
                        </motion.div>
                    </div>

                    <div className="space-y-2">
                        <h3 className="text-2xl font-bold text-slate-800 transition-colors group-hover:text-primary">
                            Drop your document here
                        </h3>
                        <p className="text-slate-400 font-medium">
                            Supports PDFs up to 50MB
                        </p>
                    </div>

                    <div className="mt-10 flex gap-4">
                        <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 rounded-xl text-slate-500 text-xs font-bold border border-slate-100">
                            <span className="w-2 h-2 rounded-full bg-emerald-500" />
                            Security Encrypted
                        </div>
                        <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 rounded-xl text-slate-500 text-xs font-bold border border-slate-100">
                            <span className="w-2 h-2 rounded-full bg-primary" />
                            Structure Analysis
                        </div>
                    </div>
                </div>
            </motion.div>

            <div className="mt-8 grid grid-cols-3 gap-6">
                {[
                    { label: 'Auto-Structure', icon: '🤖' },
                    { label: 'Compliance-Ready', icon: '⚖️' },
                    { label: 'Batch Support', icon: '📦' }
                ].map((item, i) => (
                    <motion.div
                        key={item.label}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 + i * 0.1 }}
                        className="flex flex-col items-center gap-2"
                    >
                        <span className="text-2xl">{item.icon}</span>
                        <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">{item.label}</span>
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
