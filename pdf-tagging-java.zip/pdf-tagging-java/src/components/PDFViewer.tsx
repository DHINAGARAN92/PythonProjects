import React, { useState, useRef, useCallback } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Info, X } from 'lucide-react';
import type { Tag, StructureItem } from '../types';
import { cn } from '../utils/cn';

// Set worker source
pdfjs.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.mjs',
    import.meta.url,
).toString();

interface PDFViewerProps {
    file: File;
    tags: Tag[];
    structure?: StructureItem[];
    onAddTag: (tag: Omit<Tag, 'id'>) => void;
    onRemoveTag: (id: string) => void;
    activeColor: string;
}

export const PDFViewer: React.FC<PDFViewerProps> = ({
    file,
    tags,
    structure = [],
    onAddTag,
    onRemoveTag,
    activeColor
}) => {
    const [numPages, setNumPages] = useState<number>(0);
    const [pageDimensions, setPageDimensions] = useState<Record<number, { width: number, height: number }>>({});
    const [scale] = useState(1.0);
    const [hoveredStructure, setHoveredStructure] = useState<number | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    const onDocumentLoadSuccess = ({ numPages }: { numPages: number }) => {
        setNumPages(numPages);
    };

    const handlePageLoadSuccess = (pageIndex: number, { originalWidth, originalHeight }: { originalWidth: number, originalHeight: number }) => {
        setPageDimensions(prev => ({
            ...prev,
            [pageIndex]: { width: originalWidth, height: originalHeight }
        }));
    };

    const handlePageClick = useCallback((e: React.MouseEvent, pageIndex: number) => {
        const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;
        const y = (e.clientY - rect.top) / rect.height;

        onAddTag({
            x,
            y,
            text: '', // Text will be set by the active selection in App.tsx
            color: activeColor,
            pageIndex,
        });
    }, [activeColor, onAddTag]);

    return (
        <div ref={containerRef} className="w-full flex flex-col items-center py-12 px-4 gap-12 select-none">
            <Document
                file={file}
                onLoadSuccess={onDocumentLoadSuccess}
                loading={
                    <div className="flex flex-col items-center gap-4 text-slate-400 p-20 glass-panel rounded-3xl">
                        <Loader2 className="animate-spin w-10 h-10 text-primary" />
                        <p className="font-bold text-sm uppercase tracking-widest">Hydrating Document...</p>
                    </div>
                }
                className="flex flex-col gap-12"
            >
                {Array.from(new Array(numPages), (_, index) => (
                    <div key={`page_${index + 1}`} className="group relative">
                        {/* Page Shadow & Border */}
                        <div className="absolute -inset-4 bg-slate-400/10 rounded-[1rem] blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />

                        <div className="relative bg-white shadow-[0_20px_50px_rgba(0,0,0,0.1),0_0_0_1px_rgba(0,0,0,0.05)] rounded-sm overflow-hidden ring-1 ring-slate-900/5">
                            <Page
                                pageNumber={index + 1}
                                scale={scale}
                                renderTextLayer={false}
                                renderAnnotationLayer={false}
                                className="bg-white"
                                onLoadSuccess={(page) => handlePageLoadSuccess(index, page)}
                            />

                            {/* Interaction Layer */}
                            <div
                                className="absolute inset-0 cursor-crosshair z-10"
                                onClick={(e) => handlePageClick(e, index)}
                                onMouseLeave={() => setHoveredStructure(null)}
                            >
                                {/* Auto-Tag Highlight Layer */}
                                {pageDimensions[index] && structure
                                    .filter(item => item.page === index + 1)
                                    .map((item, i) => {
                                        const { width, height } = pageDimensions[index];
                                        const [x, y, w, h] = item.rect;
                                        const isHovered = hoveredStructure === i;

                                        const style = {
                                            left: `${(x / width) * 100}%`,
                                            top: `${((height - (y + h)) / height) * 100}%`,
                                            width: `${(w / width) * 100}%`,
                                            height: `${(h / height) * 100}%`,
                                        };

                                        return (
                                            <div
                                                key={`struct_${i}`}
                                                className={cn(
                                                    "absolute border rounded-sm transition-all duration-300 pointer-events-auto cursor-help",
                                                    isHovered
                                                        ? "border-primary bg-primary/10 shadow-[0_0_10px_rgba(99,102,241,0.2)] z-30"
                                                        : "border-primary/20 bg-primary/[0.03] hover:border-primary/40 hover:bg-primary/[0.05]"
                                                )}
                                                style={style}
                                                onMouseEnter={() => setHoveredStructure(i)}
                                            >
                                                <AnimatePresence>
                                                    {isHovered && (
                                                        <motion.div
                                                            initial={{ opacity: 0, scale: 0.8, y: -10 }}
                                                            animate={{ opacity: 1, scale: 1, y: 0 }}
                                                            exit={{ opacity: 0, scale: 0.8, y: -10 }}
                                                            className="absolute -top-8 left-0 glass-panel px-2 py-1 rounded text-[10px] whitespace-nowrap font-bold text-primary flex items-center gap-1.5 shadow-xl border-primary/20"
                                                        >
                                                            <div className="w-2 h-2 rounded-full bg-primary" />
                                                            {item.type}: {item.text ? `"${item.text.substring(0, 20)}..."` : 'Structural Node'}
                                                        </motion.div>
                                                    )}
                                                </AnimatePresence>
                                            </div>
                                        );
                                    })
                                }

                                {/* Manual Tags Layer */}
                                {tags
                                    .filter(t => t.pageIndex === index)
                                    .map(tag => (
                                        <motion.div
                                            key={tag.id}
                                            initial={{ scale: 0, rotate: -10 }}
                                            animate={{ scale: 1, rotate: 0 }}
                                            whileHover={{ scale: 1.05 }}
                                            className={cn(
                                                "absolute px-3 py-1.5 rounded-lg text-white font-bold text-xs shadow-[0_10px_20px_rgba(0,0,0,0.2)] cursor-grab active:cursor-grabbing select-none transform -translate-x-1/2 -translate-y-1/2 flex items-center gap-2 group z-40 border border-white/20 backdrop-brightness-110",
                                            )}
                                            style={{
                                                left: `${tag.x * 100}%`,
                                                top: `${tag.y * 100}%`,
                                                backgroundColor: tag.color
                                            }}
                                            onClick={(e) => e.stopPropagation()}
                                        >
                                            <div className="w-1.5 h-1.5 rounded-full bg-white opacity-50" />
                                            {tag.text || 'MARK'}
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    onRemoveTag(tag.id);
                                                }}
                                                className="ml-1 w-5 h-5 flex items-center justify-center rounded-full bg-black/10 hover:bg-black/20 transition-colors"
                                            >
                                                <X className="w-3 h-3" />
                                            </button>
                                        </motion.div>
                                    ))}
                            </div>
                        </div>

                        {/* Page Information Badge */}
                        <div className="absolute top-4 right-4 z-40">
                            <div className="bg-white/80 backdrop-blur-md px-3 py-1.5 rounded-full shadow-lg border border-white/50 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Layer: Analysis</span>
                                <div className="w-px h-3 bg-slate-200" />
                                <span className="text-xs font-black text-slate-800 tracking-tighter">{index + 1} / {numPages}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </Document>

            {/* Empty Context Hint */}
            {numPages > 0 && (
                <div className="flex items-center gap-2 text-slate-400 bg-slate-100 px-6 py-3 rounded-2xl border border-slate-200/50">
                    <Info className="w-4 h-4" />
                    <p className="text-xs font-bold uppercase tracking-widest">End of Document Architecture</p>
                </div>
            )}
        </div>
    );
};
