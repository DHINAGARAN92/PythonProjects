import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfName;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfString;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.canvas.parser.PdfCanvasProcessor;
import com.itextpdf.kernel.pdf.canvas.parser.listener.IPdfTextLocation;
import com.itextpdf.kernel.pdf.canvas.parser.listener.RegexBasedLocationExtractionStrategy;
import com.itextpdf.kernel.pdf.extgstate.PdfExtGState;
import com.itextpdf.kernel.pdf.tagging.StandardRoles;
import com.itextpdf.kernel.pdf.tagutils.TagStructureContext;
import com.itextpdf.kernel.pdf.tagutils.TagTreePointer;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class AutoTagPDF {

    static class TextBlock {
        String type;
        int page;
        float[] rect; // [x, y, w, h]
        String text;

        public TextBlock(String type, int page, Rectangle rect, String text) {
            this.type = type;
            this.page = page;
            this.rect = new float[] { rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight() };
            this.text = text;
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.err.println("Usage: java -jar autotag.jar <input.pdf> <output.pdf>");
            System.exit(1);
        }

        String inputPath = args[0];
        String outputPath = args[1];
        String jsonOutputPath = outputPath + ".json";

        System.out.println("Processing: " + inputPath);

        PdfReader reader = new PdfReader(inputPath);
        PdfWriter writer = new PdfWriter(outputPath);
        PdfDocument pdf = new PdfDocument(reader, writer);
        pdf.setTagged();

        List<TextBlock> detectedStructure = new ArrayList<>();

        TagStructureContext context = new TagStructureContext(pdf);
        TagTreePointer pointer = new TagTreePointer(pdf);
        context.normalizeDocumentRootTag();

        int numberOfPages = pdf.getNumberOfPages();
        for (int i = 1; i <= numberOfPages; i++) {
            PdfPage page = pdf.getPage(i);
            pointer.setPageForTagging(page);

            // Add Page Section (Sect)
            pointer.addTag(StandardRoles.SECT);
            context.getPointerStructElem(pointer).getPdfObject().put(PdfName.T, new PdfString("Page-" + i));

            RegexBasedLocationExtractionStrategy strategy = new RegexBasedLocationExtractionStrategy(".*");
            new PdfCanvasProcessor(strategy).processPageContent(page);

            List<IPdfTextLocation> locations = new ArrayList<>(strategy.getResultantLocations());
            // Sort top-to-bottom (Y desc), then left-to-right (X asc)
            locations.sort((a, b) -> {
                int yComp = Float.compare(b.getRectangle().getY(), a.getRectangle().getY());
                if (Math.abs(b.getRectangle().getY() - a.getRectangle().getY()) < 5) {
                    return Float.compare(a.getRectangle().getX(), b.getRectangle().getX());
                }
                return yComp;
            });

            PdfCanvas canvas = new PdfCanvas(page);
            float lastY = -1;
            boolean inDiv = false;
            int sectionCount = 0;

            for (int idx = 0; idx < locations.size(); idx++) {
                IPdfTextLocation loc = locations.get(idx);
                Rectangle rect = loc.getRectangle();
                String text = loc.getText();
                if (rect == null || text == null || text.trim().isEmpty())
                    continue;

                float currentY = rect.getY();
                float currentX = rect.getX();

                // Grouping logic: Detect if we should start a new Div
                boolean isNewSection = (lastY != -1 && (lastY - currentY) > 30);
                if (isNewSection && inDiv) {
                    pointer.moveToParent();
                    inDiv = false;
                }

                if (!inDiv) {
                    pointer.addTag(StandardRoles.DIV);
                    sectionCount++;
                    String title = "Section_" + sectionCount;
                    if (text.length() > 3 && text.length() < 30 && text.toUpperCase().equals(text)) {
                        title = text.trim();
                    }
                    context.getPointerStructElem(pointer).getPdfObject().put(PdfName.T, new PdfString(title));
                    inDiv = true;
                }

                // Inner grouping: Detect columns
                boolean isColumn = false;
                if (idx + 1 < locations.size()) {
                    Rectangle nextRect = locations.get(idx + 1).getRectangle();
                    if (nextRect != null && Math.abs(nextRect.getY() - currentY) < 5
                            && (nextRect.getX() - (currentX + rect.getWidth())) > 30) {
                        isColumn = true;
                    }
                }

                if (isColumn) {
                    pointer.addTag(StandardRoles.DIV);
                    context.getPointerStructElem(pointer).getPdfObject().put(PdfName.T, new PdfString("ColumnGroup"));
                }

                // Add Tag (Paragraph or Header)
                String role = StandardRoles.P;
                if (rect.getHeight() > 10 || (text.toUpperCase().equals(text) && text.length() > 5)) {
                    role = StandardRoles.H1;
                }

                pointer.addTag(role);
                pointer.getProperties().setActualText(text);
                context.getPointerStructElem(pointer).getPdfObject().put(PdfName.T,
                        new PdfString(text.substring(0, Math.min(text.length(), 25))));

                // CONTENT MAPPING: Create Invisible but Rendered Anchor
                // We use transparency (alpha=0) to ensure it's "there" for Acrobat but
                // invisible to users.
                canvas.saveState();
                PdfExtGState transparency = new PdfExtGState().setFillOpacity(0f).setStrokeOpacity(0f);
                canvas.setExtGState(transparency);

                canvas.openTag(pointer.getTagReference());
                canvas.rectangle(rect);
                canvas.fill(); // Must call painting operator to anchor the tag
                canvas.closeTag();

                canvas.restoreState();

                pointer.moveToParent();

                if (isColumn)
                    pointer.moveToParent();

                detectedStructure.add(new TextBlock(role, i, rect, text));
                lastY = currentY;
            }

            if (inDiv)
                pointer.moveToParent(); // Close Div
            pointer.moveToParent(); // Close Sect
        }

        pdf.close();

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter fw = new FileWriter(jsonOutputPath)) {
            gson.toJson(detectedStructure, fw);
        }

        System.out.println("Structure exported to: " + jsonOutputPath);
        System.out.println("PDF Tagged with Fully Transparent Anchors Successfully -> " + outputPath);
    }
}
