const express = require('express');
const multer = require('multer');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Ensure uploads and output directories exist
const UPLOAD_DIR = path.resolve(__dirname, 'uploads');
const OUTPUT_DIR = path.resolve(__dirname, 'output');
const PYTHON_SCRIPT_PATH = path.resolve(__dirname, '../python-core/autotag.py');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);
if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR);

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
        // Sanitize filename to remove spaces and special characters
        const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
        cb(null, Date.now() + '-' + sanitizedName);
    },
});

const upload = multer({ storage });

app.post('/api/tag', upload.single('pdf'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }

    const inputPath = req.file.path;
    const outputFilename = `tagged-${req.file.filename}`;
    const outputPath = path.resolve(OUTPUT_DIR, outputFilename);

    console.log(`Input: ${inputPath}`);
    console.log(`Output Target: ${outputPath}`);

    // Check if Python script exists
    if (!fs.existsSync(PYTHON_SCRIPT_PATH)) {
        console.error(`Python Script Not Found at: ${PYTHON_SCRIPT_PATH}`);
        return res.status(500).json({ error: 'Python Auto-Tagging tool not found.' });
    }

    // Execute Python CLI
    // Note: 'python' is used as the executable. Ensure it's in the system PATH.
    const pythonExecutable = 'python';

    console.log(`Spawning Python: ${pythonExecutable}`);
    console.log(`Args: ${PYTHON_SCRIPT_PATH} ${inputPath} ${outputPath}`);

    const child = spawn(pythonExecutable, [PYTHON_SCRIPT_PATH, inputPath, outputPath]);

    let stdoutData = '';
    let stderrData = '';

    child.stdout.on('data', (data) => {
        stdoutData += data;
        console.log(`Python stdout: ${data}`);
    });

    child.stderr.on('data', (data) => {
        stderrData += data;
        console.error(`Python stderr: ${data}`);
    });

    child.on('close', (code) => {
        if (code !== 0) {
            console.error(`Python process exited with code ${code}`);
            return res.status(500).json({ error: 'Failed to process PDF', details: stderrData });
        }

        console.log(`Python process completed successfully.`);

        // Short delay to ensure file handle is released
        setTimeout(() => {
            // Verify file exists before sending
            if (!fs.existsSync(outputPath)) {
                console.error(`Error: Output file not created at ${outputPath}`);
                return res.status(500).json({ error: 'Output file generation failed.' });
            }

            // Read the generated JSON structure
            const jsonPath = outputPath + '.json';
            let structureData = [];
            if (fs.existsSync(jsonPath)) {
                try {
                    const jsonContent = fs.readFileSync(jsonPath, 'utf8');
                    structureData = JSON.parse(jsonContent);
                    console.log(`Loaded structure data: ${structureData.length} items`);
                } catch (e) {
                    console.error('Failed to parse structure JSON:', e);
                }
            } else {
                console.warn('Structure JSON key not found at:', jsonPath);
            }

            console.log(`File created successfully. Sending response.`);

            // Send output as JSON with download URL and structure
            res.json({
                downloadUrl: `/api/download/${outputFilename}`,
                structure: structureData
            });
        }, 1000); // 1 second delay to ensure file handle is released
    });

    child.on('error', (err) => {
        console.error(`Failed to start Python process: ${err}`);
        res.status(500).json({ error: 'Failed to start tagging process', details: err.message });
    });
});

// Serve the output directory statically
app.use('/output', express.static(OUTPUT_DIR));

// Dedicated download endpoint
app.get('/api/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.resolve(OUTPUT_DIR, filename);

    console.log(`Download request for: ${filename}`);
    console.log(`Full path: ${filePath}`);

    if (!fs.existsSync(filePath)) {
        console.error(`Download failed: File not found at ${filePath}`);
        return res.status(404).json({ error: 'File not found' });
    }

    try {
        const stats = fs.statSync(filePath);
        res.setHeader('Content-Length', stats.size);
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

        const fileStream = fs.createReadStream(filePath);
        fileStream.pipe(res);

        fileStream.on('error', (err) => {
            console.error('Stream error during download:', err);
            if (!res.headersSent) {
                res.status(500).json({ error: 'Internal server error during download' });
            }
        });
    } catch (err) {
        console.error('Error handling download request:', err);
        res.status(500).json({ error: 'Server error during download setup' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Python Core expected at: ${PYTHON_SCRIPT_PATH}`);
});
