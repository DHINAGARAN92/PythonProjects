export interface Tag {
    id: string;
    x: number; // 0-1 percentage relative to page width
    y: number; // 0-1 percentage relative to page height
    text: string;
    color: string;
    pageIndex: number; // 0-based
}
export interface StructureItem {
    type: string;
    page: number; // 1-based
    rect: [number, number, number, number]; // [x, y, w, h] in PDF points
    text: string;
}
