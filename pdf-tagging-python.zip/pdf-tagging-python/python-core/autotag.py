import sys
import os
import json
import fitz  # PyMuPDF
import pikepdf
from pikepdf import Name, Dictionary, Array

def analyze_layout(input_path):
    """Analyzes PDF layout and returns structural items with coordinates."""
    doc = fitz.open(input_path)
    structure_items = []
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        height = page.rect.height
        
        # Get blocks (text and coordinates)
        try:
            blocks = page.get_text("dict")["blocks"]
        except Exception:
            continue
            
        for b in blocks:
            if "lines" not in b:
                continue
                
            block_text = ""
            max_font_size = 0
            is_bold = False
            
            # Combine lines and find dominant styling
            for line in b["lines"]:
                for span in line["spans"]:
                    block_text += span["text"] + " "
                    max_font_size = max(max_font_size, span["size"])
                    if span["flags"] & 2: # Bold flag
                        is_bold = True
            
            block_text = block_text.strip()
            if not block_text:
                continue
                
            # Determine Tag Type
            tag_type = "P"
            if max_font_size > 14:
                tag_type = "H1"
            elif max_font_size > 12 or is_bold:
                tag_type = "H2"
            
            rect = b["bbox"]
            structure_items.append({
                "page": page_num + 1,
                "type": tag_type,
                "text": block_text,
                "rect": [rect[0], height - rect[3], rect[2] - rect[0], rect[3] - rect[1]],
                "bbox": rect
            })
            
    doc.close()
    return structure_items

def apply_tagging(input_path, output_path, items):
    """Applies structural tagging to the PDF using pikepdf."""
    with pikepdf.open(input_path) as pdf:
        # 1. Setup Root Structure
        catalog = pdf.Root
        
        if Name.StructTreeRoot not in catalog:
            print("Initializing new StructTreeRoot...")
            struct_tree = pdf.make_indirect(Dictionary(
                Type=Name.StructTreeRoot,
                K=Array([])
            ))
            catalog.StructTreeRoot = struct_tree

        root_struct_node = catalog.StructTreeRoot
        
        # Ensure MarkInfo
        if Name.MarkInfo not in catalog:
            catalog.MarkInfo = Dictionary(Marked=True)
        else:
            catalog.MarkInfo.Marked = True
            
        # Mapping pages to their structure items
        page_items = {}
        for item in items:
            p = item["page"] - 1
            if p not in page_items:
                page_items[p] = []
            page_items[p].append(item)
            
        # 2. Process each page
        for page_idx in range(len(pdf.pages)):
            if page_idx not in page_items:
                continue
                
            page = pdf.pages[page_idx]
            
            # Create a Section for this page
            sect = pdf.make_indirect(Dictionary(
                Type=Name.StructElem,
                S=Name.Sect,
                T=f"Page-{page_idx + 1}",
                P=root_struct_node,
                K=Array([])
            ))
            root_struct_node.K.append(sect)
            
            mcid_counter = 0
            for item in page_items[page_idx]:
                itype = str(item.get("type", "P")).strip()
                if not itype: itype = "P"
                
                try:
                    # Create the structural element using raw dictionary syntax
                    elem_dict = Dictionary()
                    elem_dict[Name.Type] = Name.StructElem
                    elem_dict[Name.S] = Name(f"/{itype}")
                    elem_dict[Name.T] = item.get("text", "")[:30]
                    elem_dict[Name.P] = sect
                    elem_dict[Name.K] = mcid_counter
                    elem_dict[Name.Pg] = page.obj
                    
                    elem = pdf.make_indirect(elem_dict)
                    sect.K.append(elem)
                    mcid_counter += 1
                except Exception as e:
                    print(f"Warning: Failed to tag item {itype}: {e}")
                
        # Save output
        pdf.save(output_path)

def main():
    if len(sys.argv) < 3:
        print("Usage: python autotag.py <input.pdf> <output.pdf>")
        sys.exit(1)
        
    input_pdf = sys.argv[1]
    output_pdf = sys.argv[2]
    
    if not os.path.exists(input_pdf):
        print(f"Error: Input file found: {input_pdf}")
        sys.exit(1)
        
    print(f"Processing: {input_pdf}")
    try:
        items = analyze_layout(input_pdf)
        print(f"Extracted {len(items)} items.")
        
        apply_tagging(input_pdf, output_pdf, items)
        print(f"Succesfully saved tagged PDF to {output_pdf}")
        
        # Save JSON
        with open(output_pdf + ".json", "w", encoding="utf-8") as f:
            json.dump(items, f, indent=2)
            
    except Exception as e:
        print(f"CRITICAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
